# Getting Started with Create React App

To run this project, first run 

### `npm install`

It will install the required packages. To run the application, run the following command in the terminal. 

### `npm start`

Open [http://localhost:3000](http://localhost:3000) to view it in your browser.
